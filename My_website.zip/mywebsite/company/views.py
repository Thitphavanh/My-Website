from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import *
from songline import Sendline # pip install songline # ລະບົບສົ່ງໄລນ໌
from .emailsystem import sendthai # ລະບົບສົ່ງເມລລ໌
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.core.files.storage import FileSystemStorage # Image
from django.core.paginator import Paginator # Pagnator

def Login(request):

	context = {} # ສິ່ງທີ່ຈະແນບໄປ 
	if request.method == 'POST':
		data = request.POST.copy()
		username = data.get('username')
		password = data.get('password')

		try:
			user = authenticate(username=username, password=password)
			login(request,user)
			return redirect('profile-page')
		except:
			context['message'] = 'username ຫຼື password ອາດບໍ່ຖືກຕ້ອງ ກະລຸນາຕິດຕໍ່ແອັດມິນ.'

	return render(request, 'company/login.html',context)

# def Home(request):
# 	return HttpResponse('<h1>Hello World!</h1> <br> <p>by Phenomenal Company</p>')

def Home(request):
	allproduct = Product.objects.all() # SELECT * from product
	product_per_page = 6
	paginator = Paginator(allproduct, product_per_page)
	page = request.GET.get('page') 
	allproduct = paginator.get_page(page)
	print('COUNT:',len(allproduct))

	context = {'allproduct':allproduct}
	# ແຍກແຖວລະ 3 ຄໍລັມ 
	allrow = []
	row = []
	for i,p in enumerate(allproduct):
		if i % 3 == 0:
			if i != 0:
				# ຖ້າບໍ່ແມ່ນ i = 0 ຈະເພີ່ມເຂົ້າ allrow
				allrow.append(row)
			row = []
			row.append(p)
		else:
			row.append(p)
	allrow.append(row)
	context['allrow'] = allrow

	return render(request, 'company/home.html',context)

def AboutUs(request):
	return render(request, 'company/aboutus.html')


def Service(request):
	return render(request, 'company/service.html')

def ContextUs(request):

	context = {} # ສິ່ງທີ່ຈະແນບໄປ

	if request.method == 'POST':
		data = request.POST.copy()
		title = data.get('title')
		email = data.get('email')
		detail = data.get('detail')
		print(title)
		print(email)
		print(detail)
		print('---------------')

		# ກໍລະນີ user ບໍ່ໃສ່ຂໍ້ມູນ
		if title == '' and email == '':
			context['message'] = 'ສະບາຍດີ ລົບກວນພິມຫົວຂໍ້ ແລະ ອີເມລ໌ຂອງທ່ານ ເພາະຈະສົ່ງຄຳຕອບບໍ່ໄດ້.'
			return render(request, 'company/context.html',context)

		# ເມື່ອໄດ້ຂໍ້ມູນແລ້ວຈະເຮັດການບັນທຶກຂໍ້ມູນ
		# Contactlist(title=title,email=email,detail=detail).save() 
		newrecord = Contactlist()
		newrecord.title = title
		newrecord.email = email
		newrecord.detail = detail
		newrecord.save()
		context['message'] = 'ຕອນນີ້ໄດ້ຮັບຂໍ້ຄວາມແລ້ວ ດຽວເຮົາຈະຕິດຕໍ່ກັບພາຍໃນ 24 ຊົ່ວໂມງ.'

		#ແຈ້ງອີເມລລ໌ຕອບກັບ
		text = 'ສະບາຍດີລູກຄ້າ\n\nທາງເຮົາໄດ້ຮັບຂໍ້ມູນທີ່ລູກຄ້າໄດ້ສົ່ງມາແລ້ວ ຈະຕິດຕໍ່ກັບໃຫ້ໄວທີ່ສຸດ'
		sendthai(email,'Phenomenal Book Cloud : ສອບຖາມຂໍ້ມູນ',text)
	
		# ສົ່ງໄລນ໌ from songline import Sendline
		#token = 'RZEZTc419q5EB4Hb7am7NikPehX4BWpOu6GCE7UbT07'
		#m = Sendline(token)
		#m.sendtext('\nຫົວຂໍ້:{}\nອີເມລລ໌:{}\n>>> {}'.format(title,email,detail))

	return render(request, 'company/context.html',context)

# from django.shortcuts import render, redirect
@login_required
def Accountant(request):
	# if request.user.profile.usertype != 'accountant':
	allow_user = ['accountant','admin']
	if request.user.profile.usertype not in allow_user:
		return redirect('home-page')

	#contact = Contactlist.objects.all().order_by('-id')
	contact = Contactlist.objects.all() 
	context = {'contact':contact}
	return render(request, 'company/accountant.html',context)

# from django.contrib.auth.models import User
def Register(request):

	context = {} # ສິ່ງທີ່ຈະແນບໄປ

	if request.method == 'POST':
		data = request.POST.copy()
		fullname = data.get('fullname')
		mobile = data.get('mobile')
		username = data.get('username')
		password = data.get('password')
		password2 = data.get('password2')
	
		try:
			check = User.objects.get(username=username)
			context['warning'] = 'Email : {} ມີໃນລະບົບແລ້ວ ກະລຸນາໃຊ້ Email ອື່ນໆ'.format(username)
			context['fullname'] = fullname
			context['mobile'] = mobile
			return render(request, 'company/register.html',context)
		except:
			if password != password2:
				context['warning'] = 'ກະລຸນາໃສ່ລະຫັດຜ່ານໃຫ້ຖືກຕ້ອງທັງສອງຊ່ອງ'
				return render(request, 'company/register.html',context)

			newuser = User()
			newuser.username = username
			newuser.email = username
			newuser.first_name = fullname
			newuser.set_password(password)
			newuser.save()

			u = uuid.uuid1()
			token = str(u)

			newprofile = Profile()
			newprofile.user = User.objects.get(username=username)
			newprofile.mobile = mobile
			newprofile.verify_token = token
			newprofile.save()
			text = 'ກະລຸນາກົດຈາກລິ້ງຄ໌ນີ້ ເພື່ອຍືນຍັນການເປັນສະມາຊິກ\n\nLink: http://localhost:8000/verify-email/' + token
			sendthai(username,'ຍືນຍັນການສະໝັກເປັນສະມາຊິກ (Phenimenal Book Cloud)',text)
			return redirect('profile-page')

		try:
			user = authenticate(username=username, password=password)
			login(request,user)
		except:
			context['message'] = 'username ຫຼື password ອາດບໍ່ຖືກຕ້ອງ ກະລຸນາຕິດຕໍ່ແອັດມິນ.'

	return render(request, 'company/register.html',context)

def Verify_Success(request,token):
	context = {}
	try:
		check = Profile.objects.get(verify_token=token)
		check.verified = True
		check.point = 100
		check.save()
				
	except:
		context['error'] = 'ລິ້ງຄ໌ສຳຫຼັບຍັນຍັນບໍ່ຖືກຕ້ອງ ກະລຸນາກ໊ອປປີ້ມາວາງໃນເວ໊ບບຣາວເຊີຣ໌ແທນ'
	return render(request,'company/verifyemail.html',context)

@login_required
def ProfilePage(request):
	context = {}
	profileuser = Profile.objects.get(user=request.user)
	context['profile'] = profileuser
	return render(request, 'company/profile.html',context)
	
import uuid
def ResetPassword(request):
	context = {} # ສິ່ງທີ່ຈະແນບໄປ 
	if request.method == 'POST':
		data = request.POST.copy()
		username = data.get('username')

		try:
			user = User.objects.get(username=username)
			u = uuid.uuid1()
			token = str(u)
			newreset = ResetPasswordToken()
			newreset.user = user
			newreset.token = token
			newreset.save()
			text = 'ກະລຸນາກົດຈາກລິ້ງຄ໌ນີ້ເພື່ອ reset\n\nLink: http://localhost:8000/reset-new-password/' + token
			sendthai(username,'reset password link (Phenomenal Book Cloud)',text)
			# https://phenomenal.com/reset-new-password/12ete11et54443113115434
			context['message'] = 'ກະລຸນາກວດສອບອີເມລ໌ລ່າສຸດຂອງເຈົ້າ ລະບົບໄດ້ສົ່ງລິ້ງຄ໌ reset password ໄປແລ້ວ'	

		except:
			context['message'] = 'Email ຂອງເຈົ້າບໍ່ມີໃນລະບົບ ກະລຸນາກວດສອບຄວາມຖືກຕ້ອງ ຫຼື ສະໝັກສະມາຊິກໃໝ່'

	return render(request, 'company/resetpassword.html',context)

def ResetNewPassword(request,token):
	context = {} 
	print('token:',token)
	try:
		check = ResetPasswordToken.objects.get(token=token)
		if request.method == 'POST':
			data = request.POST.copy()
			password1 = data.get('resetpassword1')
			password2 = data.get('resetpassword2')
			if password1 == password2:
				user = check.user
				user.set_password(password1)
				user.save()
				user = authenticate(username=user.username,password=password1)
				login(request,user)
				return redirect('profile-page')
			else:
				context['error'] = 'ລະຫັດຜ່ານທັງສອງຊ່ອງບໍ່ຖືກຕ້ອງ ກະລຸນາພິມໃໝ່'		
	except:
		context['error'] = 'ລິ້ງຄ໌ສຳຫຼັບ reset password ຂອງເຈົ້າບໍ່ຖືກຕ້ອງກະລຸນາ reset ໃໝ່'

	return render(request,'company/resetnewpassword.html',context)

def ActionPage(request,cid):
	# cid = Contactlist ID
	context = {}
	contact = Contactlist.objects.get(id=cid)
	context['contact'] = contact

	try:
		action = Action.objects.get(contactlist=contact)
		context['action'] = action
	except:
		pass

	if request.method == 'POST':
		data = request.POST.copy()
		detail = data.get('detail')
		print(data)
		if 'save' in data:
			print('save data')
			try:
				check = Action.objects.get(contactlist=contact)
				check.actiondetail = detail
				check.save()
				context['action'] = check
			except:
				new = Action()
				new.contactlist = contact
				new.actiondetail = detail
				new.save()
				context['action'] = new
		elif 'delete' in data:
			print('delete data')
			try:
				# check = Action.objects.get(contactlist=contact)
				# check.delete()
				contact.delete()
				return redirect('accountant-page')
			except:
				pass

		elif 'completed' in data:
			print('mark completed')
			contact.complete = True
			contact.save()
			return redirect('accountant-page')

	return render(request,'company/action.html',context)

# Add Product
def Addproduct(request):
	if request.method == 'POST':
		data = request.POST.copy()
		title = data.get('title')
		description = data.get('description')
		price = data.get('price')
		quantity = data.get('quantity')
		instock = data.get('instock')
		
		print(title)
		print(description)
		print(price)
		print(quantity)
		print(instock)

		print('File:', request.FILES)

		new = Product()
		new.title = title
		new.description = description
		new.price = float(price)
		new.quantity = int(quantity)
		if instock == 'instock':
			new.instock = True
		if 'picture' in request.FILES:
			file_image = request.FILES['picture']
			file_image_name = file_image.name.replace(' ','')
			# from django.core.files.storage import FileSystemStorage
			fs = FileSystemStorage(location='media/product')
			filename = fs.save(file_image_name, file_image)
			upload_file_url = fs.url(file_image)
			print('picture URL:',upload_file_url)
			new.picture = '/product' + upload_file_url[6:]

		if 'specfile' in request.FILES:
			file_image = request.FILES['specfile']
			file_image_name = file_image.name.replace(' ','')
			# from django.core.files.storage import FileSystemStorage
			fs = FileSystemStorage(location='media/specfile')
			filename = fs.save(file_image_name, file_image)
			upload_file_url = fs.url(file_image)
			print('picture URL:',upload_file_url)
			new.specfile = '/specfile' + upload_file_url[6:]

		new.save()

	return render(request,'company/Addproduct.html')

