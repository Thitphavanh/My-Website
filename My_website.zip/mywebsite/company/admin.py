from django.contrib import admin
from .models import *

admin.site.register(Product)  # ເປັນການເຮັດໃຫ້ແອັດມິນສາມາດເຫັນຖານຂໍ້ມູນໄດ້
admin.site.register(Contactlist)  # ເພີ່ມ model ໃໝ່ໃນລາຍການ
admin.site.register(Profile)
admin.site.register(ResetPasswordToken)
admin.site.register(Action)
