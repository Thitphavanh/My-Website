from django.urls import path
from .views import *

urlpatterns = [
    path('',Home, name='home-page'),
    path('about/',AboutUs, name='about-page'), # localhost:8000/about
    path('service/',Service, name='service-page'), # localhost:8000/service
    path('context/',ContextUs, name='context-page'),
    path('accountant/',Accountant, name='accountant-page'),
    path('register/',Register, name='register-page'),
    path('profile/',ProfilePage, name='profile-page'),
    path('reset-password/',ResetPassword, name='reset-password'),
    path('reset-new-password/<str:token>/',ResetNewPassword, name='reset-new-password'),
    path('verify-email/<str:token>/',Verify_Success, name='verify-email'),
    path('action-detail/<int:cid>/',ActionPage,name='action-page'),
    path('add-product/',Addproduct,name='add-product'),
]   
