import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

def sendthai(sendto,subj="ທົດສອບສົ່ງອີເມລລ໌",detail="ສະບາຍດີ!\nເຈົ້າສະບາຍດີບໍ?\n"):

	myemail = 'thitphavanh23@gmail.com'
	mypassword = 'hery18205208038'
	receiver = sendto

	msg = MIMEMultipart('alternative')
	msg['Subject'] = subj
	msg['From'] = 'ລະບົບສົ່ງເມລລ໌ຂາຍໜັງສືຂອງ Phenomenal Book Cloud'
	msg['To'] = receiver
	text = detail

	part1 = MIMEText(text, 'plain')
	msg.attach(part1)

	s = smtplib.SMTP('smtp.gmail.com:587')
	s.ehlo()
	s.starttls()

	s.login(myemail, mypassword)
	s.sendmail(myemail, receiver.split(','), msg.as_string())
	s.quit()
	print('ສົ່ງແລ້ວ')

#------------Start sending---------------
subject = 'ສະບາຍດີ!!'

msg = '''Hi


ທົດສອບສົ່ງຂໍ້ຄວາມ

ລອງຂຽນເວັບ

ທຸກໆວັນພຸດ
'''

sendthai('thitphavanh23@gmail.com',subject,msg)
